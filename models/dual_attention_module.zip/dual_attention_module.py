import torch
import torch.nn as nn
import torch.nn.functional as F


class dual_attention_module(nn.Module):

    def __init__(self, size):
        super(dual_attention_module, self).__init__()
        self.bn_layer = nn.BatchNorm1d(size[0])


    def PAM(self, Feature, alpha):
        # Position Attention Module

        # Feature.size() = CxHxW
        size = Feature.size()

        # A.size() = CxHxW
        a = Feature

        #apply bn and relu
        Feature = self.bn_layer(Feature)
        Feature = F.relu(Feature)


        # c.size() = CxN     - B, C and D in the paper
        c = Feature.reshape(size[0], -1)

        # cb = C' * B
        # cb.size() = NxN
        cb = torch.matmul(c.permute(1,0), c)

        # S.size() = N*N ( row : prob.)
        s = F.softmax(cb, dim=0)

        # Feed A to convolutional layer with bn and relu ? apply just bn & relu ?
        # d,size() = C*N

        # d = b & c
        # e.size() = C x N
        e = torch.matmul(c, s.permute(1,0))

        # E.size() = C x H x W
        e = e.reshape(size)

        e = alpha*e + a

        return e



    def CAM(self, Feature, beta):
        # Channel Attention Module

        # Feature.size() = CxHxW
        size = Feature.size()

        # CAM is calculated w.o bn and relu
        # c.size() = CxN     - C in the paper
        a = Feature.reshape(size[0], -1)

        # aa = A * A'
        # aa.size() = C x C
        aa = torch.matmul(a, a.permute(1,0)).permute(1,0)

        # X : channel attention map
        x = F.softmax(aa, dim=0)

        # E.size() = C x N
        e = torch.matmul(x.permute(1,0), a)

        # E.size() = C x H x W
        e = e.reshape(size)

        e = beta*e + a

        return e



    def get_attention(self, Feature, alpha, beta):

        # sum fusion of PAM & CAM's result

        result = dual_attention_module.PAM(Feature, alpha) + dual_attention_module.CAM(Feature, beta)

        return result









